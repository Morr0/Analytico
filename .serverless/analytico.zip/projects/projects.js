const AWS = require('aws-sdk');
const uuid = require('uuid');
const bcrypt = require('bcrypt');

const {getUsersTable, getWebsiteAnalyticsProjectTable} = require('../utilities/AWSHelpers');


module.exports.createProject = async ({
	apiKey,
	projectName,
	website
}) => {
	const dynamoDBClient = new AWS.DynamoDB.DocumentClient();
	const userResponse = await dynamoDBClient.scan({
		TableName: getUsersTable(),
		FilterExpression: 'apiKey = :apiKey',
		ExpressionAttributeValues: {
			':apiKey': {
				'S': apiKey
			}
		}
	}).promise();
	if (userResponse.Count === 0) throw new Error('No user');

	const user = userResponse.Items[0];
	console.log('Got user', user);

	return {
		projectId: 'fdjfd',
		projectSecret: 'fdfdfdfd'
	};
};