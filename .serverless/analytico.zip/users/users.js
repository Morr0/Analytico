const AWS = require('aws-sdk');
const uuid = require('uuid');
const bcrypt = require('bcrypt');

const {getUsersTable} = require('../utilities/AWSHelpers');

const HASH_ROUNDS = 15;

module.exports.createUser = async ({
    name
}) => {
    
    const apiKey = uuid.v4();
    
    const date = new Date();
    const data = {
        id: uuid.v4(),
        name,
        createdAt: date,
        modifiedAt: date,
        apiKey
    };
    
    const dynamoDBClient = new AWS.DynamoDB();
    await dynamoDBClient.putItem({
        Item: data,
        TableName: getUsersTable()
    }).promise();

    return apiKey;
};