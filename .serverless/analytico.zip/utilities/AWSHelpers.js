module.exports.getUsersTable = () => `Analytico-${ENV}-users`;
module.exports.getWebsiteAnalyticsProjectTable = () => `Analytico-${ENV}-websiteAnalyticsProjects`;